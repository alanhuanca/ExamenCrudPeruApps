﻿using ExamenNetDeveloperCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Repositories
{
    public interface IAlumnoRepository : IRepository<Alumno>
    {
    }
}
