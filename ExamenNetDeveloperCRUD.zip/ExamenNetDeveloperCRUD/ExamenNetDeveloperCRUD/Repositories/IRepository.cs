﻿using ExamenNetDeveloperCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Repositories
{
    public interface IRepository<T> where T : BaseEntity
    {
        Task<List<Alumno>> ObtenerAlumnos();
        Task<List<Alumno>> ObtenerAlumnosPorColegio();
        Task<int> CrearAlumno(Alumno entity);
        Task<int> EliminarAlumno(int  IdAlumno);
        Task<List<Alumno>> ObtenerAlumnosPorNombreApellido(string busqueda);
    }
}
