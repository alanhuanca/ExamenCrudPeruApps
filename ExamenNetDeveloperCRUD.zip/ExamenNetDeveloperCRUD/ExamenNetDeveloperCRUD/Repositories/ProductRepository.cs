﻿using Dapper;
using ExamenNetDeveloperCRUD.Domain;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Repositories
{
    public class ProductRepository : BaseRepository, IAlumnoRepository
    {
        public ProductRepository(IConfiguration configuration)
            : base(configuration)
        {

        }

        public async Task<List<Alumno>> ObtenerAlumnos()
        {
            try
            {
                var procedure = "spGetAllAlumnos";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<Alumno>(procedure)).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<List<Alumno>> ObtenerAlumnosPorColegio()
        {
            try
            {
                var procedure = "spGetAllAlumnosPorColegio";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<Alumno>(procedure)).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> CrearAlumno(Alumno entity)
        {
            try
            {
                var query = "INSERT INTO Alumno (Nombres,Apellidos,FechaNacimiento,IdColegio,Vigente,FechaRegistro,UsuarioRegistro) VALUES (@Nombres,@Apellidos,@FechaNacimiento,@IdColegio,@Vigente,@FechaRegistro,@UsuarioRegistro)";

                var parameters = new DynamicParameters();
                parameters.Add("Nombres", entity.Nombres, DbType.String);
                parameters.Add("Apellidos", entity.Apellidos, DbType.String);
                parameters.Add("FechaNacimiento", entity.FechaNacimiento, DbType.Date);
                parameters.Add("IdColegio", entity.IdColegio, DbType.Int32);
                parameters.Add("Vigente", entity.Vigente, DbType.Boolean);
                parameters.Add("FechaRegistro", entity.FechaRegistro, DbType.DateTime);
                parameters.Add("UsuarioRegistro", entity.UsuarioRegistro, DbType.String);

                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }



        public async Task<int> EliminarAlumno(int IdAlumno)
        {
            try
            {
                var query = "UPDATE Alumno set Vigente=0 WHERE IdAlumno = @IdAlumno";

                var parameters = new DynamicParameters();
                parameters.Add("IdAlumno", IdAlumno, DbType.Int32);

                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        

        public Task<List<Alumno>> ObtenerAlumnosPorNombreApellido(string busqueda)
        {
            throw new NotImplementedException();
        }
    }
}