﻿using ExamenNetDeveloperCRUD.Domain;
using ExamenNetDeveloperCRUD.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Services
{
    public class AlumnoService : IAlumnoService
    {
        private readonly IAlumnoRepository _alumnoRepository;

        public AlumnoService(IAlumnoRepository productRepository)
        {
            _alumnoRepository = productRepository;
        }

        public async Task<int> CrearAlumno(Alumno alumno)
        {
            return await _alumnoRepository.CrearAlumno(alumno);
        }

        public async Task<int> EliminarAlumno(int IdAlumno)
        {
            return await _alumnoRepository.EliminarAlumno(IdAlumno);
        }

        public async Task<List<Alumno>> ObtenerAlumnos()
        {
            return await _alumnoRepository.ObtenerAlumnos();
        }

        public async Task<List<Alumno>> ObtenerAlumnosPorColegio()
        {
            return await _alumnoRepository.ObtenerAlumnosPorColegio();
        }

        public async Task<List<Alumno>> ObtenerAlumnosPorNombreApellido(string busqueda)
        {
            return await _alumnoRepository.ObtenerAlumnosPorNombreApellido(busqueda);
        }
    }
}
