﻿using ExamenNetDeveloperCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Services
{
    public interface IAlumnoService
    {
        public Task<List<Alumno>> ObtenerAlumnos();
        public Task<List<Alumno>> ObtenerAlumnosPorColegio();
        public Task<int> CrearAlumno(Alumno alumno);
        public Task<int> EliminarAlumno(int IdAlumno);
        public Task<List<Alumno>> ObtenerAlumnosPorNombreApellido(string busqueda);
    }
}
