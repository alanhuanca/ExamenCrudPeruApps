﻿using ExamenNetDeveloperCRUD.Domain;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ExamenNetDeveloperCRUD.Validators
{
    public class AlumnoValidator:AbstractValidator<Alumno>
    {
        public AlumnoValidator()
        {
            RuleFor(v => v.Nombres).NotEmpty().MinimumLength(5).MaximumLength(400);
            RuleFor(v => v.Apellidos).NotEmpty().MinimumLength(5).MaximumLength(400);
            RuleFor(v => v.FechaNacimiento).NotNull();
            RuleFor(v => v.IdColegio).NotNull();
            RuleFor(v => v.Vigente).NotNull();
            RuleFor(v => v.FechaRegistro).NotNull();
            RuleFor(v => v.UsuarioRegistro).NotNull();
        }
    }
}
