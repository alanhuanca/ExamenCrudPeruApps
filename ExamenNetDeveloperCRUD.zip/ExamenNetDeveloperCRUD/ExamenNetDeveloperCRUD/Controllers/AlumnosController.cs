﻿using ExamenNetDeveloperCRUD.Domain;
using ExamenNetDeveloperCRUD.Services;
using ExamenNetDeveloperCRUD.Validators;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ExamenNetDeveloperCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlumnosController : ControllerBase
    {
        private readonly IAlumnoService _alumnoService;

        public AlumnosController(IAlumnoService alumnoService)
        {
            _alumnoService = alumnoService;
        }

        // GET: api/<AlumnosController>
        [HttpGet]
        public async Task<IEnumerable<Alumno>> Get()
        {
            return await _alumnoService.ObtenerAlumnos();
        }

        

        // POST api/<AlumnosController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Alumno alumno)
        {
            try
            {
                var validator = new AlumnoValidator();
                var result = validator.Validate(alumno);
                if (result.IsValid)
                {
                    await _alumnoService.CrearAlumno(alumno);
                    return Ok();
                }
                else
                {
                    return StatusCode(StatusCodes.Status400BadRequest, result.Errors[0].ErrorMessage);
                }
                
            }
            catch (Exception ex)
            {

               return StatusCode(StatusCodes.Status500InternalServerError,ex.Message);
            }
            

        }



        // DELETE api/<AlumnosController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {

                await _alumnoService.EliminarAlumno(id);

                return Ok();
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        // GET api/<AlumnosController>/5
        [HttpGet("{id}")]
        public async Task<IEnumerable<Alumno>> Get(int id)
        {
            return await _alumnoService.ObtenerAlumnosPorColegio();
        }

        // GET api/<AlumnosController>/alumno
        [HttpGet("{buscar}")]
        public async Task<IEnumerable<Alumno>> Get(string buscar)
        {
            return await _alumnoService.ObtenerAlumnosPorNombreApellido(buscar);
        }
    }
}
